-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2023 at 03:19 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `swiss_collection`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'GAMING MOUSE & KEYBOARD BUNDLE'),
(2, 'HEADSET GAMING'),
(3, 'JOYSTICK & WHEEL'),
(4, 'KEYBOARD GAMING'),
(5, 'MOUSE GAMING'),
(6, 'KURSI GAMING'),
(7, 'MOUSE PAD GAMING'),
(8, 'SSD');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `delivered_to` varchar(150) NOT NULL,
  `phone_no` varchar(10) NOT NULL,
  `deliver_address` varchar(255) NOT NULL,
  `pay_method` varchar(50) NOT NULL,
  `pay_status` int(11) NOT NULL,
  `order_status` int(11) NOT NULL DEFAULT 0,
  `order_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `userid`, `delivered_to`, `phone_no`, `deliver_address`, `pay_method`, `pay_status`, `order_status`, `order_date`) VALUES
(1, 1, 'Self', '9802234675', 'Matepani-12', 'Cash', 0, 0, '2022-04-10'),
(3, 1, 'Test  Firstuser', '980098322', 'matepani-12', 'Khalti', 1, 0, '2022-04-18');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `detail_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `variation_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`detail_id`, `order_id`, `variation_id`, `quantity`, `price`) VALUES
(1, 1, 1, 1, 399000),
(3, 3, 3, 1, 407000);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_desc`, `product_image`, `price`, `category_id`) VALUES
(1, 'Rexus Keyboard Mouse Wireless KM9 Combo', '<p>Spesifikasi<br />\r\nKeyboard<br />\r\nMode transmisi: 2.4GHz<br />\r\nKonektor: USB receiver<br />\r\nTegangan: 3.0V / &le;5mA<br />\r\nTombol: Membran<br />\r\nJumlah tombol: 75 tombol<br />\r\nBerat: 568gram<br />\r\nDimensi: 350 x 160 x 36mm<br />\r\n<br />\r\nMouse<br />\r\nDPI: 1200<br />\r\nMode transmisi: 2.4GHz<br />\r\nKonektor: USB receiver<br />\r\nTegangan: 3.0V / &le;15mA<br />\r\nJumlah tombol: 3<br />\r\nDaya tahan switch: 3 juta klik<br />\r\nBerat: 61 Gram &plusmn; 2gram<br />\r\nDimensi: 116 x 60 x 32mm<br />\r\n<br />\r\nIsi Paket:<br />\r\n-1 buah keyboard wireless Rexus KM9<br />\r\n-1 buah mouse wirele</p>\r\n', './uploads/product-1.jpg', 399000, 1),
(2, 'Redragon Gaming Keyboard Mouse 2 in 1 Combo RGB ', 'KEYBOARD Features and Specification :<br />\r\n1). RGB full color backlit with 5 Levels mode<br />\r\n2). Adjustable breathing speed rate of LED light<br />\r\n3). 104 standard keys<br />\r\n4). 19 non-conflict keys<br />\r\n5). 12 multimedia keys<br />\r\n6). 8 independent control keys for quick management<br />\r\n<p>MOUSE Features and Specification :<br />\r\n1). 800/1600/2400/3200 DPI （P3317 sensor)<br />\r\n2). 4000 FPS, 15G ACC, 1000 polling rate<br />\r\n3). Trendy backlight RED color<br />\r\n4). 6 function buttons<br />\r\n5). 8 built-in weights<br />\r\n', './uploads/product-2.jpg', 407000, 1),
(3, 'Armaggeddon Gaming Keyboard Mechanical MKA-5R RGB [Asic 9 + Mousemat] ', '<p>Fitur dari MKA-5R<br />\r\n- High quality mechanical switches and long life up to 50 million keystrokes<br />\r\n- RGB backlights with up to 16.8 million color options<br />\r\n- Fully macro-able gaming keyboard<br />\r\n- Adjustable keys effective time in 7 speed transmission from LMS up to 16ms<br \r\n<p>Spesifikasi :<br />\r\n- Definisi tinggi 1000CPI usb optikal mouse<br />\r\n- Tahan hinggal 3 juta kali klik<br />\r\n- Gaming scroll decoder memberikan stabilitas dan akurasi<br />\r\n- Pencahayaan 7 warna dengan efek pulsasi (merah, hijau, biru, kuning, tosca, ungu, putih)<br />\r\n- Panjang kabel usb 1.35 m<br />\r\n- Suport : Win XP , Win Vista , Win 7 , Win 8 , Win 8.1 , Win 10 , MAC 1 USB Port</p>\r\n', './uploads/product-3.jpg', 456000, 1),
(4, 'Razer Kraken X - Multi Platform Black Gaming Headset ', '<p>7.1 Surround Sound<br />\r\nUltra-light at 250g<br />\r\nBendable Cardioid Microphone<br />\r\nCustom-Tuned 40 mm Drivers<br />\r\nOn-headset Controls<br />\r\nCross-Platform Compatibility<br />\r\nSignal-to-noise ratio: &gt; 60 dB<br />\r\nSensitivity (@1 kHz): -45 &plusmn; 3 dB<br />\r\nPick-up pattern: Unidirectional ECM boom</p>\r\n', './uploads/product-4.jpg', 649000, 2),
(5, 'Rexus Headset Gaming Wireless Daxa TS1 ', '<p>Best Sound Sensation<br />\r\n<br />\r\n- 3 Pilihan Equalizer, yaitu Hi-Fi, Bass, dan 3D.<br />\r\n- Rounded RGB LED 8 mode warna yang bisa dihidup-matikan.<br />\r\n- Desain elegan dan ergonomis<br />\r\n- Earcup bertipe over-ear yang nyaman dan efektif mereduksi suara dari luar. Dan juga dilengkapi dengan busa memori yang berlapis kain Fabric berpori.<br />\r\n- Mikrofon dengan busa pelindung yang dapat dicopot-pasang.<br />\r\n- Baterai tanam Lithium berkapasitas besar.</p>\r\n', './uploads/product-5.jpg', 779000, 2),
(6, 'Logitech G733 LIGHTSPEED Wireless RGB 7.1 Surround Gaming Headset ', 'SPESIFIKASI FISIK<br />\r\nPanjang: 194 mm<br />\r\nLebar: 190 mm<br />\r\nKedalaman: 83 mm<br />\r\nBerat: 278 g<br />\r\n<br />\r\nSPESIFIKASI TEKNIS<br />\r\nHeadphone:<br />\r\nDriver: PRO-G 40 mm<br />\r\nJangkauan Wireless<br />\r\nJenis Koneksi: LIGHTSPEED wireless via USB<br />\r\nDaya Tahan Baterai (dapat diisi ulang)<br />\r\nTanpa pencahayaan: 29 jam<br />\r\nPencahayaan default: 20 jam<br />\r\n\r\n', './uploads/product-6.jpg', 1899000, 2),
(7, 'Logitech G29 Driving Racing Wheel + Logitech Driving Shifter Bundling', '<p>Logitech G29 Driving Force Racing Wheel<br />\r\nSpesifikasi fisik<br />\r\nKemudi<br />\r\nTinggi: 270 mm (10,63 inci)<br />\r\nLebar: 260 mm (10,24 inci)<br />\r\nPanjang: 278 mm (10,94 inci)<br />\r\nBerat tanpa kabel: 2,25 kg (4,96 lb)<br />', './uploads/product-7.jpg', 4958000, 3),
(8, 'Logitech Extreme 3D Pro Joystick Flight Simulator untuk PC ', '<p>ISI KEMASAN<br /> Joystick<br /> Dokumentasi pengguna<br /> <br /> PERSYARATAN SISTEM<br /> Windows® 8, Windows 7 atau Windows Vista<br /> Tersedia ruang hard disk sebesar 70 MB<br /> Port USB<br /> Koneksi internet untuk pengunduhan software opsional</p>', './uploads/product-8.jpg', 600000, 3),
(9, 'Gamepad Rexus Gladius GX100 - Wireless Gaming Controller PC/ PS/ Xbox ', 'Spesifikasi<br /> -Mode Dual Terintergrasi: X-input dan Direct-input yang kompatibel untuk semua game.<br /> -Teknologi nirkabel 2.4GHz, dengan jangkauan frekuensi hingga 8 meter.<br /> -Baterai Lithium Polymer 600mAh dengan durasi pemakaian hingga 12 jam.<br /> -Waktu isi ulang baterai 2 - 3 jam.<br /> -Teknologi stik analog Eccentric 360 yang lebih nyaman digunakan.<br /> -Tombol D Cross 8-way dengan ketepatan optimal.<br />', './uploads/product-9.jpg', 229000, 3),
(10, 'Logitech G Pro X Keyboard Gaming TKL Mechanical RGB for E-Sports ', 'GX mechanical switch terbaik ini dibuat dan 100% diuji untuk menghadirkan kinerja, ketanggapan, dan daya tahan luar biasa. Kustomisasikan nuansa PRO X keyboard dengan tiga varian switch yang dapat dilepaskan.', './uploads/produk-10.jpg', 1559000, 4),
(11, 'Razer Huntsman Mini Mercury White 60% Mechanical Gaming Keyboard', '- Quality, Aluminum Construction: Covered with a matte, aluminum top frame for increased structural integrity<br /> - Oil-Resistant Doubleshot PBT Keycaps: Made of textured, high-grade PBT for a more durable and textured finish less prone to long-term grime buildup<br /> - Fully Programmable Macros: Razer Hypershift allows for all keys and keypress combinations to be remapped to execute complex commands<br /> <br /> Garansi Resmi Razer Indonesia 2 Tahun</p>', './uploads/product-11.jpg', 1969000, 4),
(12, 'Keyboard Gaming Rexus DAXA M71 Classic RGB Hotswap Wired ', 'Type C Modular Cable<br /> Dimensi dan desain yang simpel dan penuh gaya<br /> Dua varian warna:<br /> Elegant White (Switch Brown)<br /> Black Beauty (Switch Red)<br /> Teknologi Hot-swappable switch.<br /> Dilengkapi dengan fungsi Macro untuk mendukung permainan dan aktivitas mengetik yang lebih mudah dan lengkap<br />', './uploads/product-12.jpg', 549000, 4),
(13, 'Logitech G502 HERO High Performance Mouse Gaming Wired RGB ', 'Memori on-board: Hingga 5 profil (memerlukan firmware 127.1.7)<br /> LIGHTSYNC RGB: 1 zona<br /> <br /> PERSYARATAN<br /> Windows&reg; 7 atau versi terbaru<br /> macOS 10.11 atau versi terbaru<br /> Chrome OS&trade;<br /> Port USB<br /> Akses internet untuk Logitech G HUB (opsional)</p>', './uploads/product-13.jpg', 699000, 5),
(14, 'Razer Basilisk X HyperSpeed', '<p>Deskripsi Produk :<br /> Wireless Gaming Mouse with Razer&trade; HyperSpeed Technology<br /> Razer&trade; HyperSpeed Wireless<br /> Razer&trade; 5g Advanced Optical Sensor<br /> Ultra-Long Battery Life<br /> &nbsp;</p>', './uploads/product-14.jpg', 699000, 5),
(15, 'Rexus Daxa Air II Pro Wireless Gaming Mouse Air 2 Ultra Lightweight', '<p>Spesifikasi Teknis<br /> Sensor : PIXART PMW3370<br /> Frekuensi : 2.4Ghz Zero delay (dengan Nano USB)<br /> Resolusi : 100 &ndash; 19000 DPI<br /> Akselerasi maksimal : 50G<br /> Kecepatan maksimal : 400 IPS<br /> Polling Rate : 125 - 1000Hz<br /> Tingkat DPI Default : 400 - 16000 DPI (Dapat diperluas dengan software)<br /> Kabel : USB2.0<br />', './uploads/product-15.jpg', 649000, 5),
(16, 'Rexus Gaming Chair Kursi RGC 101 ', '<p>Spesifikasi Kursi Gaming<br /> - Pegangan tangan sistem 4D, dapat dinaik- turunkan, maju- mundur, serong ke ke kiri dan ke kanan, dan geser ke dalam &ndash; luar<br /> - Material permukaan: Kulit sintetis berkualitas tinggi (Polyutherane Leather)<br />', './uploads/product-19.jpg', 2499000, 6),
(17, 'MSI MAG CH120X GAMING CHAIR - CH120X ', '<p>Deskiripsi MSI MAG CH120X<br /> Complete steel frame support<br /> 180&deg; fully reclinable backrest<br /> 4D Multi-Adjustable Armrests and seat<br /> Certified Class 4 Gas Lift piston<br /> 5 star steel chair base design<br /> Incredibly smooth and silent PU casters<br /> Ergonomic headrest pillow and lumbar support cushion</p>', './uploads/product-20.jpg', 3499000, 6),
(18, 'Digital Alliance Throne RGB - Gaming Chair ', '<p>SPECIFICATION<br /> Model Throne RGB<br /> Color Black Red<br /> Foam Type Cold Molded Foam<br /> Foam Density 45 g/cm3<br /> Frame Construction Metal<br /> Chair Cover Material PU<br /> Armrest 3D<br /> Mechanism Type Butterfly<br /> Adjustable Backrest Angle 90 &ndash; 150&deg;<br /> Tilt Lock &radic;<br />', './uploads/product-21.jpg', 2550000, 6);

-- --------------------------------------------------------

--
-- Table structure for table `product_variation`
--

CREATE TABLE `product_variation` (
  `variation_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_in_stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_variation`
--

INSERT INTO `product_variation` (`variation_id`, `product_id`, `quantity_in_stock`) VALUES
(1, 1, 5),
(2, 2, 9),
(3, 2, 3),
(6, 3, 6),
(7, 4, 8),
(8, 5, 8),
(9, 6, 10),
(10, 7, 10);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(150) NOT NULL,
  `contact_no` varchar(10) NOT NULL,
  `isAdmin` int(11) NOT NULL DEFAULT 0,
  `user_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `email`, `password`, `contact_no`, `isAdmin`, `user_address`) VALUES
(1, 'Admin', 'Admin', 'admin@gmail.com', '$2y$10$j9OXXIYS0CG5AYuks62YMeDvuIpo2hZEN4CqfJfujt1yPMnoUq5C6', '9810283472', 1, 'newroad'),
(2, 'Test ', 'Firstuser', 'test@gmail.com', '$2y$10$DJOdhZy1InHTKQO6whfyJexVTZCDTlmIYGCXQiPTv7l82AdC9bWHO', '980098322', 0, 'matepani-12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`detail_id`),
  ADD KEY `variation_id` (`variation_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_variation`
--
ALTER TABLE `product_variation`
  ADD PRIMARY KEY (`variation_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `product_variation`
--
ALTER TABLE `product_variation`
  MODIFY `variation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`variation_id`) REFERENCES `product_variation` (`variation_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
