<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Validator;
use App\Models\Category;

class CategoryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function index()
    {
        $data = Category::get();
        return response()->json($data, 200);
    }

    public function show($id)
    {
        $data = Category::where('category_id', $id)->first();
        return response()->json($data, 200);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
                'category_id'        => 'required',
                'category_name'     => 'required',

            ],
            [
                'category_id'  => ':attribute harus diisi',
                'category_name'   => ':attribute harus diisi',
            ]);

        if ($validator->fails()) {
           
            return response()->json($validator->errors()->first(), 400);
            die();
        }

        $data = new Category;
        $data->category_id = $request->post('category_id');
        $data->category_name = $request->post('category_name');
        $data->save();

        return response()->json($data, 201);

    }

    public function destroy($id)
    {
        
        $data = Category::where('category_id', $id)->delete();
        return response()->json('Data berhasil dihapus', 200);
    }

}