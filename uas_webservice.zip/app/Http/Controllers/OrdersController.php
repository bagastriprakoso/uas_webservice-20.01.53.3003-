<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Validator;
use App\Models\Orders;

class OrdersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function index()
    {
        $data = Orders::get();
        return response()->json($data, 200);
    }

    public function show($id)
    {
        $data = Orders::where('order_id', $id)->first();
        return response()->json($data, 200);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
                'order_id'        => 'required',
                'userid'     => 'required',
                'delivered_to'       => 'required',
                'phone_no'          => 'required',
                'deliver_address'       => 'required',
                'pay_method'            => 'required',
                'pay_status'        => 'required',
                'order_date'        => 'required',
            ],
            [
                'order_id'  => ':attribute harus diisi',
                'userid'   => ':attribute harus diisi',
                'delivered_to'     => ':attribute harus diisi',
                'phone_no'              => ':attribute harus diisi',
                'deliver_address'       => ':attribute harus diisi',
                'pay_method'        => ':attribute harus diisi',
                'pay_status'        => ':attribute harus diisi 1 atau 0',
                'order_date'        => ':attribute harus diisi',
            ]);

        if ($validator->fails()) {
           
            return response()->json($validator->errors()->first(), 400);
            die();
        }

        $data = new Orders;
        $data->order_id = $request->post('order_id');
        $data->userid = $request->post('userid');
        $data->delivered_to = $request->post('delivered_to');
        $data->phone_no = $request->post('phone_no');
        $data->deliver_address = $request->post('deliver_address');
        $data->pay_method = $request->post('pay_method');
        $data->pay_status = $request->post('pay_status');
        $data->order_date = $request->post('order_date');
        $data->save();

        return response()->json($data, 201);

    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
                'order_id'  => 'required',
                'userid'   => 'required',
                'delivered_to'     => 'required',
                'phone_no'              => 'required',
                'deliver_address'       => 'required',
                'pay_method'        => 'required',
                'pay_status'        => 'required',
                'order_date'        => 'required',
            ]);

        if ($validator->fails()) {
           
            return response()->json($validator->errors()->first(), 400);
            die();
        }

        $data = Orders::where('order_id', $request->post('order_id'))->first();
        if( $data )
        {
            $data->order_id = $request->post('order_id') ? $request->post('order_id') : $data->order_id;
            $data->userid = $request->post('userid') ? $request->post('userid') : $data->userid;
            $data->delivered_to = $request->post('delivered_to') ? $request->post('delivered_to') : $data->delivered_to;
            $data->phone_no = $request->post('phone_no') ? $request->post('phone_no') : $data->phone_no;
            $data->deliver_address = $request->post('deliver_address') ? $request->post('deliver_address') : $data->deliver_address;
            $data->pay_method = $request->post('pay_method') ? $request->post('pay_method') : $data->pay_method;
            $data->pay_status = $request->post('pay_status') ? $request->post('pay_status') : $data->pay_status;
            $data->order_date = $request->post('order_date') ? $request->post('order_date') : $data->order_date;
            $data->save();
    
            return response()->json($data, 200);
        }else{
            return response()->json("Data tidak ditemukan", 400);
        }
        

    }

    public function destroy($id)
    {
        
        $data = Orders::where('order_id', $id)->delete();
        return response()->json('Data berhasil dihapus', 200);
    }

}