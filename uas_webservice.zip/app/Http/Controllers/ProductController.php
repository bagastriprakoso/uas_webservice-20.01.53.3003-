<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Validator;
use App\Models\Product;

class ProductController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function index()
    {
        $data = Product::get();
        return response()->json($data, 200);
    }

    public function show($id)
    {
        $data = Product::where('product_id', $id)->first();
        return response()->json($data, 200);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
                'product_id'        => 'required',
                'product_name'     => 'required',
                'product_desc'       => 'required',
                'product_image'     => 'required',
                'category_id'       => 'required',
            ],
            [
                'product_id'  => ':attribute harus diisi',
                'product_name'   => ':attribute harus diisi',
                'product_desc'     => ':attribute harus diisi',
                'product_image'     => ':attribute harus diisi',
                'price'             => ':attribute harus diisi',
                'category_id'       => ':attribute harus diisi',
            ]);

        if ($validator->fails()) {
           
            return response()->json($validator->errors()->first(), 400);
            die();
        }

        $data = new Product;
        $data->product_id = $request->post('product_id');
        $data->product_name = $request->post('product_name');
        $data->product_desc = $request->post('product_desc');
        $data->product_image = $request->post('product_image');
        $data->price= $request->post('price');
        $data->category_id = $request->post('category_id');
        $data->save();

        return response()->json($data, 201);

    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'product_id'        => 'required',
            'product_name'     => 'required',
            'product_desc'       => 'required',
            'product_image'     => 'required',
            'category_id'       => 'required',
            ]);

        if ($validator->fails()) {
           
            return response()->json($validator->errors()->first(), 400);
            die();
        }

        $data = Product::where('product_id', $request->post('product_id'))->first();
        if( $data )
        {
            $data->product_id = $request->post('product_id') ? $request->post('product_id') : $data->product_id;
            $data->product_name = $request->post('product_name') ? $request->post('product_name') : $data->product_name;
            $data->product_desc = $request->post('product_desc') ? $request->post('product_desc') : $data->product_desc;
            $data->product_image = $request->post('product_image') ? $request->post('product_image') : $data->product_image;
            $data->price= $request->post('price') ? $request->post('price') : $data->price;
            $data->category_id = $request->post('category_id') ? $request->post('category_id') : $data->category_id;
            $data->save();
    
            return response()->json($data, 200);
        }else{
            return response()->json("Data tidak ditemukan", 400);
        }
        

    }

    public function destroy($id)
    {
        
        $data = Product::where('product_id', $id)->delete();
        return response()->json('Data berhasil dihapus', 200);
    }

}