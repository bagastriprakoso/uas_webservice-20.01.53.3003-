<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Validator;
use App\Models\Users;

class UsersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function index()
    {
        $data = Users::get();
        return response()->json($data, 200);
    }

    public function show($id)
    {
        $data = Users::where('user_id', $id)->first();
        return response()->json($data, 200);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
           
                'user_id'        => 'required',
                'first_name'     => 'required',
                'last_name'       => 'required',
                'email'         => 'required',
                'password'         => 'required',
                'contact_no'        => 'required',
                'registered_at'     => 'required',
                'isAdmin'          => 'required',
                'user_address'      => 'required',
            ],
            [
                'user_id'  => ':attribute harus diisi',
                'first_name'   => ':attribute harus angka',
                'last_name'     => ':attribute minimal :min karakter',
                'email'             => ':attribute harus diisi',
                'password'          => ':attribute harus diisi',
                'contact_no'        => ':attribute harus diisi',
                'registered_at'     => ':attribute harus diisi',
                'isAdmin'           => ':attribute harus diisi',
                'user_address'      => ':attribute harus diisi',
            ]);

        if ($validator->fails()) {
           
            return response()->json($validator->errors()->first(), 400);
            die();
        }

        $data = new Users;
        $data->user_id = $request->post('user_id');
        $data->first_name = $request->post('first_name');
        $data->last_name = $request->post('last_name');
        $data->email = $request->post('email');
        $data->password = $request->post('password');
        $data->contact_no = $request->post('contact_no');
        $data->registered_at = $request->post('registered_at');
        $data->isAdmin = $request->post('isAdmin');
        $data->user_address = $request->post('user_address');
        $data->save();

        return response()->json($data, 201);

    }


}