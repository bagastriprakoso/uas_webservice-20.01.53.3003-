<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Validator;
use App\Models\Variation;

class VariationController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function index()
    {
        $data = Variation::get();
        return response()->json($data, 200);
    }

    public function show($id)
    {
        $data = Variation::where('variation_id', $id)->first();
        return response()->json($data, 200);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
                'variation_id'        => 'required',
                'product_id'     => 'required',
                'quantity_in_stock'       => 'required',
            ],
            [
                'variation_id'  => ':attribute harus diisi',
                'product_id'   => ':attribute harus angka',
                'quantity_in_stock'     => ':attribute minimal :min karakter',
            ]);

        if ($validator->fails()) {
           
            return response()->json($validator->errors()->first(), 400);
            die();
        }

        $data = new Variation;
        $data->variation_id = $request->post('variation_id');
        $data->product_id = $request->post('product_id');
        $data->quantity_in_stock = $request->post('quantity_in_stock');
        $data->save();

        return response()->json($data, 201);

    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
                'variation_id'        => 'required',
                'product_id'   => 'required|nullable',
                'quantity_in_stock'     => 'sometimes|nullable',
            ]);

        if ($validator->fails()) {
           
            return response()->json($validator->errors()->first(), 400);
            die();
        }

        $data = Variation::where('variation_id', $request->post('variation_id'))->first();
        if( $data )
        {
            $data->variation_id = $request->post('variation_id') ? $request->post('variation_id') : $data->name;
            $data->product_id = $request->post('product_id') ? $request->post('product_id') : $data->address;
            $data->quantity_in_stock = $request->post('quantity_in_stock') ? $request->post('quantity_in_stock') : $data->phone;
            $data->save();
    
            return response()->json($data, 200);
        }else{
            return response()->json("Data tidak ditemukan", 400);
        }
        

    }

    public function destroy($id)
    {
        
        $data = Variation::where('variation_id', $id)->delete();
        return response()->json('Data berhasil dihapus', 200);
    }

}