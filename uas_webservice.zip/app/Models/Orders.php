<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Orders extends Model
{
    public $timestamps = false;
    protected $primaryKey = 'order_id';
    protected $table = 'orders';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'order_id', 'user_id', 'delivered_to', 'phone_no', 'deliver_address', 'pay_method', 'pay_status', 'order_date'
    ];

}