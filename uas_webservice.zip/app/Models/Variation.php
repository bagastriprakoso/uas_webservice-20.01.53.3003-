<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Variation extends Model
{
    public $timestamps = false;
    protected $primaryKey = 'variation_id';
    protected $table = 'product_variation';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'variation_id', 'product_id', 'quantity_in_stock'
    ];

}