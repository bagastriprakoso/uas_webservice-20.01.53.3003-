<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

//generate key
$router->get('/key', function() {
    return \Illuminate\Support\Str::random(32);
});

//routes tabel users
$router->get('/users', 'UsersController@index' );
$router->get('/users/{id}', 'UsersController@show' );

// routes tabel category
$router->get('/category', 'CategoryController@index' );
$router->get('/category/{id}', 'CategoryController@show' );
$router->post('/category', 'CategoryController@store' );
$router->delete('/category/delete/{id}', 'CategoryController@destroy' );

//ROUTES TABEL ORDERS
$router->get('/orders', 'OrdersController@index' );
$router->get('/orders/{id}', 'OrdersController@show' );
$router->post('/orders', 'OrdersController@store' );
$router->post('/orders/update', 'OrdersController@update' );
$router->delete('/orders/delete/{id}', 'OrdersController@destroy' );

//routes tabel product
$router->get('/product', 'ProductController@index' );
$router->get('/product/{id}', 'ProductController@show' );
$router->post('/product', 'ProductController@store' );
$router->post('/product/update', 'ProductController@update' );
$router->delete('/product/delete/{id}', 'ProductController@destroy' );

//routes tabel product variation
$router->get('/product_variation', 'VariationController@index' );
$router->get('/product_variation/{id}', 'VariationController@show' );
$router->post('/product_variation', 'VariationController@store' );
$router->post('/product_variation/update', 'VariationController@update' );
$router->delete('/product_variation/delete/{id}', 'VariationController@destroy' );